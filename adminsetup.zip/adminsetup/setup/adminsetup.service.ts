import { Injectable } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class AdminsetupService {

  constructor() { }

form: FormGroup= new FormGroup(
  {
    TrainNumber : new FormControl(''),
    TrainName  : new FormControl(''),
    FromCity  : new FormControl(''),
    ToCity  : new FormControl(''),
    FromDate  : new FormControl(''),
    StartTime : new FormControl(''),
    ToDate  : new FormControl(''),
    EndTime :new FormControl(''),
    SleeperTicketCost  : new FormControl(''),
    AC2TicketCost  : new FormControl(''),
    AC3TicketCost  : new FormControl('')
  }
);

}
