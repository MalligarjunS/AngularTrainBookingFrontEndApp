import { Component, OnInit } from '@angular/core';
import{ FormGroup,Validators,FormBuilder,FormControl} from '@angular/forms'



export interface City {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-search-page',
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.css']
})
export class SearchPageComponent implements OnInit {

  searchForm: FormGroup;

  FromCityToCity(form : FormControl){
    const cityVal= form.get('FromCity').value === form.get('ToCity').value;
  return cityVal ?{FromCityToCityMsg: true} : null;
  }

  constructor(private formBuilder : FormBuilder) {
    this.searchForm= this.formBuilder.group({
      FromCity  : [''],
      ToCity  : [''],
      StartDate  : ['',Validators.required]
      
    }),{
      Validators: this.FromCityToCity
    }
   }

   FromCityToCityMsg(){
    return "From Station To station can not be same";
  }

  cities: City[] = [
    {value: 'Hyderabad', viewValue: 'Hyderabad'},
    {value: 'Chennai', viewValue: 'Chennai'},
    {value: 'Mumbai', viewValue: 'Mumbai'},
    {value: 'Delhi', viewValue: 'Delhi'},
    {value: 'Bangalore', viewValue: 'Bangalore'}
    
  ];

  ngOnInit() {
  }

}
