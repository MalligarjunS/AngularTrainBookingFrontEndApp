import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from '../app.component';
//import {SignupComponent} from './signup.component'
//import { LoginComponent } from './login.component';
//import { LoginRoutingModule } from './login-routing.module';

@NgModule({
    imports: [
        ReactiveFormsModule,
        FormsModule
    ],
    declarations: [AppComponent],
    exports: [ReactiveFormsModule,
        FormsModule]
})

export class TrainModule { }