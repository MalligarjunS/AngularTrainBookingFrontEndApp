import { Component, OnInit } from '@angular/core';
import{ FormGroup,Validators,FormBuilder,FormControl} from '@angular/forms'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { conditionallyCreateMapObjectLiteral } from '@angular/compiler/src/render3/view/util';

export interface City {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-train',
  templateUrl: './train.component.html',
  styleUrls: ['./train.component.css']
})

export class TrainComponent implements OnInit {

  trainForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder
) {
    this.createForm();
}

  ngOnInit() {
  }

  AlertMessage(){
    return alert("Train added successfully");
  }
  
  CityValidation(form:FormControl){
   const cityVal = form.get('FromCity').value === form.get('ToCity').value;
   return cityVal ? {FromCityToCity: true}: null ;
  } 

  FromCityToCity(){
    return "From Station To station can not be same";
  }

  cities: City[] = [
    {value: 'Hyderabad', viewValue: 'Hyderabad'},
    {value: 'Chennai', viewValue: 'Chennai'},
    {value: 'Mumbai', viewValue: 'Mumbai'},
    {value: 'Delhi', viewValue: 'Delhi'},
    {value: 'Bangalore', viewValue: 'Bangalore'}
    
  ];

timePattern="^([0-1][0-9]|[2][0-3]):([0-5][0-9])$";

  createForm()
  {
  this.trainForm= this.formBuilder.group({
    
      TrainNumber :['',[Validators.required,Validators.minLength(4)]],
      TrainName  : ['',[Validators.required,Validators.minLength(4)]],
      FromCity  : [''],
      ToCity  : [''],
      StartDate  : ['',Validators.required],
      StartTime : ['',[Validators.required,Validators.pattern(this.timePattern)]],
      EndDate  : ['',Validators.required],
      EndTime : ['',[Validators.required,Validators.pattern(this.timePattern)]],
      SleeperTicketCost  : ['',Validators.required],
      AC2TicketCost  : ['',Validators.required],
      AC3TicketCost  : ['',Validators.required]
    },
    {
      validators: this.CityValidation
    }
    )};

    public findInvalidControls() {
      const invalid = [];
      const controls = this.trainForm.controls;
      for (const name in controls) {
          if (controls[name].invalid) {
              invalid.push(name);
          }
      }
      if(invalid.values!==null || invalid.values!==undefined){
      return ("Invalid Fields : " + invalid) ;
      }
      else{
      return "Form is valid";
      }
  }

}
