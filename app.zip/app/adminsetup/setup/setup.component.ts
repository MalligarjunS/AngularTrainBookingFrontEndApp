import { Component, OnInit,ViewChild } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

export interface TrainElement {
  name: string;
  number: number;
  fromCity:string;
  toCity:string;
  starttime:string;
  endtime: string;
  sleeperCharge : number;
  Ac2Charge : number;
  Ac3Charge : number;
}

const Train_Setup:  TrainElement[]=[
  {name:'Hyderabad Exp',number:1234,fromCity:'Hyderabad',toCity:'Chennai',starttime:'',endtime:'',sleeperCharge:234,Ac2Charge:344,Ac3Charge:566},
  {name:'Chennai Exp',number:1235,fromCity:'Chennai',toCity:'Mumbai',starttime:'',endtime:'',sleeperCharge:234,Ac2Charge:344,Ac3Charge:566},
  {name:'Mumbai Exp',number:1236,fromCity:'Mumbai',toCity:'Bangalore',starttime:'',endtime:'',sleeperCharge:234,Ac2Charge:344,Ac3Charge:566},
  {name:'Bangalore Exp',number:1237,fromCity:'Bangalore',toCity:'Delhi',starttime:'',endtime:'',sleeperCharge:234,Ac2Charge:344,Ac3Charge:566},
  {name:'Delhi Exp',number:1238,fromCity:'Delhi',toCity:'Hyderabad',starttime:'',endtime:'',sleeperCharge:234,Ac2Charge:344,Ac3Charge:566}
  
]


@Component({
  selector: 'app-setup',
  templateUrl: './setup.component.html',
  styleUrls: ['./setup.component.css']
})
export class SetupComponent implements OnInit {


  constructor() {
     }

  ngOnInit() {
   }
   displayedColumns: string[] = ['name', 'number', 'starttime','endtime','sleeperCharge','Ac2Charge','Ac3Charge'];
   TrainSetup = Train_Setup;
 
  
}

