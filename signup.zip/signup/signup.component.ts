import { Component, OnInit } from '@angular/core';
import {FormControl, Validators,FormBuilder,FormGroup} from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

 // constructor(private form : FormBuilder) { }

  ngOnInit() {
  }

  //name=new FormControl('', [Validators.required, Validators.minLength]);
  //email = new FormControl('', [Validators.required, Validators.email]);

  //getErrorMessage() {
  //  return this.email.hasError('required') ? 'Not a valid email':null;
  //}
  signupForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder
) {
    this.createForm();
}

pwdValidator(form : FormControl){
const condition=form.get('password').value !== form.get('confirmpwd').value;
return condition ? {PasswordDoNotMatch: true} : null;
}

emailPattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$";
phonePattern="[6-9][0-9]{9}";
passwordPattern="((?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,20})";

createForm() {
    this.signupForm = this.formBuilder.group({
        fname: ['', [
            Validators.required,
            Validators.minLength(3)
        ]],
        email : ['',[
          Validators.required,
          Validators.pattern(this.emailPattern)
        ]],
        phoneno : ['',[
          Validators.required,
          Validators.pattern(this.phonePattern)
        ]],
        password: ['',[
          Validators.required,
          Validators.pattern(this.passwordPattern)
        ]],
        confirmpwd: ['',[
          Validators.required,
          Validators.pattern(this.passwordPattern)
        ]]
      },
      {
        validators : this.pwdValidator
      }
      );
    }
    PwdDoNotMatch(){
      return "Password do not match";
    }

  fullnameValidation(){
    return this.requiredValiationMsg();  }

    emailValidation(){
      return this.requiredValiationMsg();  }
  

    phoneValidation(){
      return this.requiredValiationMsg();  }

      pwdValidation(){
        return this.requiredValiationMsg(); 
      }
      

    requiredValiationMsg(){
      return "This field is missing/incorrect";
    }  
}
