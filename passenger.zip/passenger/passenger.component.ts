import { Component, OnInit } from '@angular/core';
//import {FormControl,Validators} from '@angular/forms';
import { RouterModule,Routes} from '@angular/router'

//const routes: Routes =[
//  {path :"",redirectTo : "/passenger",pathMatch : ""}];
  

@Component({
  selector: 'app-passenger',
  templateUrl: './passenger.component.html',
  styleUrls: ['./passenger.component.css']
})
export class PassengerComponent implements OnInit {

  constructor() { }

  PersonNumber=1;

AddPassengers(){
  this.PersonNumber+=1;
}
TotalTicketFare(){
  return alert("The total ticket cost is " +this.PersonNumber);
}
//new FormControl({value: field.value}, [Validators.required, Validators.pattern(/^-?(0|[1-9]\d*)?$/)])

  ngOnInit() {
  }

}
